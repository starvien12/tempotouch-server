"""Small WSGI application for the Android TempoTouch schedule planner."""

import hashlib
import json
import os
import sqlite3
import time
from http import HTTPStatus
from pathlib import Path

from licenses import load_public_key, verify_token
from planner import DEFAULT_MODEL, Planner, UpstreamUnavailable, parse_json, validate_input


class Limited(Exception):
    def __init__(self, seconds):
        self.seconds = seconds


class RateLimits:
    """A persistent fixed-window quota shared by all workers on this host."""

    def __init__(self, path, per_minute=6, per_day=60):
        self.path = str(path)
        self.per_minute = per_minute
        self.per_day = per_day
        db = sqlite3.connect(self.path, timeout=2)
        try:
            db.execute("""CREATE TABLE IF NOT EXISTS usage(
                token_id TEXT PRIMARY KEY, expires INTEGER NOT NULL,
                minute INTEGER NOT NULL, minute_count INTEGER NOT NULL,
                day INTEGER NOT NULL, day_count INTEGER NOT NULL)""")
            db.execute("CREATE INDEX IF NOT EXISTS usage_expiry ON usage(expires)")
            db.commit()
        finally:
            db.close()

    def take(self, claims, now):
        token_id = hashlib.sha256(claims["id"].encode("ascii")).hexdigest()
        minute, day = now // 60, now // 86400
        db = sqlite3.connect(self.path, timeout=2)
        try:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM usage WHERE expires <= ?", (now,))
            row = db.execute("SELECT minute, minute_count, day, day_count FROM usage WHERE token_id=?",
                             (token_id,)).fetchone()
            used_minute = row[1] if row and row[0] == minute else 0
            used_day = row[3] if row and row[2] == day else 0
            if used_day >= self.per_day:
                raise Limited((day + 1) * 86400 - now)
            if used_minute >= self.per_minute:
                raise Limited((minute + 1) * 60 - now)
            db.execute("INSERT OR REPLACE INTO usage VALUES (?, ?, ?, ?, ?, ?)",
                       (token_id, claims["exp"], minute, used_minute + 1, day, used_day + 1))
            db.commit()
        finally:
            db.close()


class App:
    def __init__(self, public_key, planner, limits, clock=time.time):
        self.public_key = public_key
        self.planner = planner
        self.limits = limits
        self.clock = clock

    def __call__(self, env, start_response):
        def response(status, value, extra=()):
            data = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()
            headers = [("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", "no-store"),
                       ("Content-Length", str(len(data))), ("X-Content-Type-Options", "nosniff")]
            start_response(str(status) + " " + HTTPStatus(status).phrase, headers + list(extra))
            return [data]

        def error(status, text, extra=()):
            return response(status, {"error": text}, extra)

        if env.get("PATH_INFO") != "/v1/plan":
            return error(404, "Không tìm thấy đường dẫn.")
        if env.get("REQUEST_METHOD") != "POST":
            return error(405, "Dùng POST cho đường dẫn này.", [("Allow", "POST")])
        auth = env.get("HTTP_AUTHORIZATION", "")
        now = int(self.clock())
        try:
            if len(auth) > 4200 or not auth.startswith("Bearer "):
                raise ValueError("bearer")
            claims = verify_token(auth[7:], self.public_key, now)
        except ValueError:
            return error(401, "Mã bản quyền không hợp lệ hoặc đã hết hạn.",
                         [("WWW-Authenticate", 'Bearer realm="TempoTouch"')])
        if env.get("CONTENT_TYPE", "").split(";", 1)[0].strip().lower() != "application/json":
            return error(415, "Nội dung phải là JSON.")
        raw_len = env.get("CONTENT_LENGTH") or ""
        if not raw_len or not raw_len.isascii() or not raw_len.isdecimal():
            return error(411, "Thiếu độ dài nội dung.")
        if len(raw_len) > 6 or int(raw_len) > 65536:
            return error(413, "Yêu cầu quá dài.")
        size = int(raw_len)
        try:
            raw = env["wsgi.input"].read(size)
            if len(raw) != size:
                raise ValueError("incomplete request")
            request = validate_input(parse_json(raw.decode("utf-8")))
        except (OSError, ValueError, RecursionError):
            return error(400, "Dữ liệu yêu cầu không hợp lệ.")
        try:
            self.limits.take(claims, now)
        except Limited as limit:
            return error(429, "Đã đạt giới hạn sử dụng. Hãy thử lại sau.",
                         [("Retry-After", str(limit.seconds))])
        except sqlite3.Error:
            return error(503, "Dịch vụ tạm thời chưa sẵn sàng.")
        try:
            plan = self.planner(request)
        except UpstreamUnavailable:
            return error(503, "Dịch vụ AI tạm thời chưa trả được đề xuất.")
        return response(200, plan)


def create_app():
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Hosting Secret OPENAI_API_KEY is required")
    default_pin = Path(__file__).resolve().with_name("tempo_license_public.der")
    pin = load_public_key(os.environ.get("TEMPO_LICENSE_PUBLIC_KEY", str(default_pin)))
    limits = RateLimits(os.environ.get("TEMPO_LIMIT_DB", "tempo-usage.sqlite3"))
    return App(pin, Planner(key, os.environ.get("OPENAI_MODEL", DEFAULT_MODEL)), limits)
